package Athlete;

import java.util.ArrayList;

public class NacionalTeam {
    private String color;
    private String country;
    private ArrayList<Athlete> belongs = new ArrayList<>();

    public NacionalTeam() {
    }

    public NacionalTeam(String color, String country) {
        this.color = color;
        this.country = country;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }


    public ArrayList<Athlete> getBelongs() {
        return belongs;
    }

    public void setBelongs(ArrayList<Athlete> belongs) {
        this.belongs = belongs;
    }

    public void addAthlete(Athlete athlete){
        belongs.add(athlete);
    }
}
