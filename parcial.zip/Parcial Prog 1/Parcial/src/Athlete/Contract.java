package Athlete;

public interface Contract {
    public double calculatesIMC();
    public boolean extraWeight(double IMC);
    public double takeKeystrokes();
}

