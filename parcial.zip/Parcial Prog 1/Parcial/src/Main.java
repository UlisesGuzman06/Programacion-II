import Athlete.*;
import Campus.*;

public class Main {
    public static void main(String[] args) {
        Athlete PlayerArg1 = new Athlete(45966443,"Lucas Alario",1.80,20,90);
        Athlete PlayerBrazil1 = new Athlete(37488590,"Neymar da Silva",1.75,32,70);
        Athlete PlayerArg2 = new Athlete(34233434,"Lionel Messi",1.71,36,78);
        Athlete PlayerArg3 = new Athlete(32445543,"Pablo Mouche",1.90,40,135);

        NacionalTeam arg = new NacionalTeam("celeste","Argentina");
        NacionalTeam brz = new NacionalTeam("Verde","Brasil");


        arg.addAthlete(PlayerArg1);
        arg.addAthlete(PlayerArg2);
        arg.addAthlete(PlayerArg3);
        brz.addAthlete(PlayerBrazil1);


        Tournament mundial = new Tournament(1,"Copa del mundo");
        Tournament cupAmer = new Tournament(2,"Copa America");


        mundial.addAthleteTournament(PlayerArg1);
        mundial.addAthleteTournament(PlayerArg1);
        mundial.addAthleteTournament(PlayerArg1);
        mundial.addAthleteTournament(PlayerBrazil1);

        cupAmer.addAthleteTournament(PlayerArg1);
        cupAmer.addAthleteTournament(PlayerArg1);
        cupAmer.addAthleteTournament(PlayerArg1);
        cupAmer.addAthleteTournament(PlayerBrazil1);

        Facility stadium1 = new Facility("Argentine","Mendoza","Malvina Argentina","Estadio Mundialista");
        Facility stadium2 = new Facility("Argentine","Buenos Aires","Monumental","Estadio de futbol");
        Facility stadium3= new Facility("Argentine","Mendoza","Omar Higinio Sperdutti","Estadio de futbol");

        mundial.addFacilityTournament(stadium1);
        mundial.addFacilityTournament(stadium2);
        mundial.addFacilityTournament(stadium3);

        cupAmer.addFacilityTournament(stadium1);
        cupAmer.addFacilityTournament(stadium2);
        cupAmer.addFacilityTournament(stadium3);

        Site site1 = new Site("24/9/2025","15:00");
        Site site2 = new Site("27/10/2025","14:00");
        stadium2.addFacility(mundial);
        stadium2.addFacility(cupAmer);
        System.out.println("Nombre del tercer atleta de la segunda prueba desde una instalacion: " + stadium2.getIsMade().get(1).getCompetitor().get(2).getName());
        System.out.println("Codigo de la segunda prueba desde una instalacion: ");
        System.out.println("Altura de todos los jugadores de un equipo: ");
        for (Athlete athlete : arg.getBelongs()){
            System.out.println(athlete.getName()+": "+athlete.getHeight());
        }
        System.out.println("Peso extra de los jugadores");
        for (Athlete athlete : arg.getBelongs()){
            athlete.extraWeight(athlete.calculatesIMC());
        }
    }
}