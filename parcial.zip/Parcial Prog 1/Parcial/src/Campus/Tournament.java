package Campus;

import Athlete.Athlete;

import java.util.ArrayList;

public class Tournament {
    private int code;
    private String title;
    private ArrayList<Athlete> competitor
            = new ArrayList<>();
    private ArrayList<Facility> where = new ArrayList<>();

    public Tournament(int code, String title) {

        this.code = code;
        this.title = title;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<Athlete> getCompetitor() {
        return competitor
                ;
    }

    public void setCompetitor(ArrayList<Athlete> competitor
    ) {
        this.competitor = competitor
        ;
    }

    public ArrayList<Facility> getWhere() {
        return where;
    }

    public void setWhere(ArrayList<Facility> where) {
        this.where = where;
    }

    public void addAthleteTournament(Athlete athlete){competitor.add(athlete);
    }
    public void addFacilityTournament(Facility facility){where.add(facility);}

}

